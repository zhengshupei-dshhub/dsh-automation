import { execFileSync, spawn } from 'node:child_process'
import {
  chmodSync,
  copyFileSync,
  cpSync,
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  renameSync,
  rmSync,
  statSync,
  unlinkSync,
} from 'node:fs'
import { homedir } from 'node:os'
import { fileURLToPath } from 'node:url'
import { dirname, join, resolve } from 'node:path'
import { createInterface } from 'node:readline'
import { createHelperLog, defaultHelperLogPath } from './helper-log.js'
import {
  CompanionMessageKind,
  createMessage,
  encodeMessage,
} from './protocol.js'

const here = dirname(fileURLToPath(import.meta.url))
const defaultHelperPath = resolve(here, '..', 'runtime', 'helper.py')
const bundledHelperPath = resolve(here, '..', 'runtime', 'bin', 'win32-x64', 'dsh-dafeiyu-helper.exe')
const linuxBundledHelperPath = resolve(here, '..', 'runtime', 'bin', 'linux-x64', 'dsh-dafeiyu-helper')
const linuxArm64BundledHelperPath = resolve(
  here,
  '..',
  'runtime',
  'bin',
  'linux-arm64',
  'dsh-dafeiyu-helper',
)
const darwinBundledHelperPath = resolve(
  here,
  '..',
  'runtime',
  'bin',
  'darwin',
  'dsh-dafeiyu-helper.app',
  'Contents',
  'MacOS',
  'dsh-dafeiyu-helper',
)
const packageVersion = JSON.parse(
  readFileSync(resolve(here, '..', 'package.json'), 'utf8'),
).version
const snapshotMessageKinds = new Set([
  CompanionMessageKind.HELLO,
  CompanionMessageKind.STATE,
  CompanionMessageKind.TASK,
  CompanionMessageKind.TASKS,
  CompanionMessageKind.CONFIG,
  CompanionMessageKind.BALANCE,
])
const coalescibleMessageKinds = new Set([
  ...snapshotMessageKinds,
  CompanionMessageKind.PULSE,
])

function isWsl() {
  if (process.platform !== 'linux') return false
  try {
    return readFileSync('/proc/sys/fs/binfmt_misc/WSLInterop', 'utf8').includes('enabled')
  } catch {
    try {
      return /microsoft/i.test(readFileSync('/proc/version', 'utf8'))
    } catch {
      return false
    }
  }
}

// First launches of the PyInstaller one-file Helper extract the whole Qt runtime
// (~108 MB) into the OS temp directory. Real-time antivirus scanning can stretch
// that well past the old 60 s budget (issue #88), so cold starts get a longer
// budget while restarts of an already-working Helper stay short.
const COLD_START_TIMEOUT_MS = 180000
const WARM_START_TIMEOUT_MS = 60000
const RESTART_START_TIMEOUT_MS = 90000
// Leftovers are only removed once they are clearly dead. A second DSH profile
// may still be running from its own extraction directory.
const STALE_EXTRACTION_AGE_MS = 24 * 60 * 60 * 1000

function linuxHelperForArch(arch, {
  x64 = linuxBundledHelperPath,
  arm64 = linuxArm64BundledHelperPath,
} = {}) {
  if (arch === 'x64') return x64
  if (arch === 'arm64') return arm64
  return undefined
}

function shouldUseBundledHelper({
  platform = process.platform,
  arch = process.arch,
  isWslEnv = isWsl(),
  fileExists = existsSync,
} = {}) {
  if (platform === 'win32' || isWslEnv) return fileExists(bundledHelperPath)
  if (platform === 'linux') {
    // Never treat an x86-64 binary as usable on aarch64: execve returns
    // ENOEXEC, libc retries through /bin/sh and the resulting syntax error hides
    // the real cause (issue #91).
    const bundled = linuxHelperForArch(arch)
    return bundled !== undefined && fileExists(bundled)
  }
  return platform === 'darwin' && fileExists(darwinBundledHelperPath)
}

// PyInstaller one-file Helpers extract to `_MEI*` under the child's temp
// directory. Pointing that directory at the plugin cache keeps the leftovers
// discoverable, so stale copies can be reclaimed (issue #88). WSL launches a
// Windows EXE, whose temp directory belongs to Windows, so it is excluded.
function defaultHelperTempDirectory({
  platform = process.platform,
  env = process.env,
  home = homedir(),
} = {}) {
  if (platform === 'win32') {
    const base = env.LOCALAPPDATA || join(home, 'AppData', 'Local')
    return join(base, 'dsh-dafeiyu', 'tmp')
  }
  if (platform === 'linux') {
    const base = env.XDG_CACHE_HOME || join(home, '.cache')
    return join(base, 'dsh-dafeiyu', 'tmp')
  }
  return undefined
}

function cleanStaleExtractionDirectories(directory, {
  maxAgeMs = STALE_EXTRACTION_AGE_MS,
  now = Date.now(),
  readDirectory = readdirSync,
  fileStat = statSync,
  remove = rmSync,
} = {}) {
  const removed = []
  let entries
  try {
    entries = readDirectory(directory, { withFileTypes: true })
  } catch {
    return removed
  }
  for (const entry of entries) {
    if (!entry.isDirectory() || !entry.name.startsWith('_MEI')) continue
    const path = join(directory, entry.name)
    try {
      if (now - fileStat(path).mtimeMs < maxAgeMs) continue
      remove(path, { recursive: true, force: true })
      removed.push(path)
    } catch {
      // A directory another process still owns is simply retried next start.
    }
  }
  return removed
}

function isBundledHelperCommand(command) {
  if (!command) return false
  const filename = String(command).replaceAll('\\', '/').split('/').pop()
  return filename === 'dsh-dafeiyu-helper' || filename === 'dsh-dafeiyu-helper.exe'
}

function ensureExecutable(filePath) {
  try {
    chmodSync(filePath, 0o755)
  } catch {
    // npm archives assembled on another OS may lose the executable bit. The
    // following spawn will surface a useful error if the best-effort repair fails.
  }
}

function toWindowsPath(path) {
  return execFileSync('wslpath', ['-w', path], { encoding: 'utf8' }).trim()
}

function defaultCmdExe({ wslpath = defaultWslPath, fileExists = existsSync } = {}) {
  // WSL visual mode launches the bundled EXE through Windows cmd.exe. cmd.exe
  // is usually NOT on the WSL PATH (System32 is not appended by default), so
  // never rely on `cmd.exe` being resolvable: convert the Windows absolute path
  // with wslpath and only fall back to the bare name as a last resort.
  try {
    const candidate = wslpath('C:\\Windows\\System32\\cmd.exe')
    if (candidate && fileExists(candidate)) return candidate
  } catch {
    // Fall through to the bare-name fallback below.
  }
  return 'cmd.exe'
}

function defaultWslPath(...args) {
  return execFileSync('wslpath', args, { encoding: 'utf8' }).trim()
}

function defaultWindowsLocalAppData({
  cmdExe = defaultCmdExe,
  wslpath = defaultWslPath,
  run = execFileSync,
} = {}) {
  const windowsPath = run(
    cmdExe(),
    ['/d', '/c', 'echo %LOCALAPPDATA%'],
    { encoding: 'utf8', windowsHide: true },
  ).trim()
  if (!windowsPath || windowsPath.includes('%LOCALAPPDATA%')) {
    throw new Error('Windows LOCALAPPDATA is unavailable')
  }
  return wslpath('-u', windowsPath)
}

// On native Windows LOCALAPPDATA is already an environment variable; the
// cmd.exe probe only exists for WSL, where the value must be read from the
// Windows side and mapped back to a /mnt path.
function defaultLocalAppData() {
  if (process.platform === 'win32' && process.env.LOCALAPPDATA) return process.env.LOCALAPPDATA
  return defaultWindowsLocalAppData()
}

function cacheWslBundledHelper({
  bundledPath,
  version = packageVersion,
  localAppData = defaultLocalAppData,
  assetsSource = resolve(here, '..', 'assets'),
  fileExists = existsSync,
  makeDirectory = mkdirSync,
  copyFile = copyFileSync,
  copyTree = cpSync,
  fileStat = statSync,
  moveFile = renameSync,
  removeFile = unlinkSync,
} = {}) {
  const sourceSize = fileStat(bundledPath).size
  const safeVersion = String(version || 'unknown').replaceAll(/[^a-zA-Z0-9._-]/g, '_')
  const cacheDirectory = resolve(localAppData(), 'dsh-dafeiyu', safeVersion)
  // Published versions are immutable. Including the source size also keeps
  // local/repacked builds with the same package version from reusing a stale
  // executable without hashing the large PyInstaller archive on every start.
  const cachedPath = resolve(cacheDirectory, `dsh-dafeiyu-helper-${sourceSize}.exe`)
  // The frozen helper resolves assets from the directory next to the
  // executable (see runtime/helper.py bundle_root), so the cache carries them
  // and the npm package ships a single copy instead of embedding three.
  const cachedManifest = resolve(cacheDirectory, 'assets', 'pet-manifest.json')
  const exeCurrent = fileExists(cachedPath) && fileStat(cachedPath).size === sourceSize
  if (exeCurrent && fileExists(cachedManifest)) return cachedPath
  makeDirectory(cacheDirectory, { recursive: true })
  if (!exeCurrent) {
    const temporaryPath = `${cachedPath}.${process.pid}.tmp`
    try {
      copyFile(bundledPath, temporaryPath)
      if (!fileExists(cachedPath)) {
        try {
          moveFile(temporaryPath, cachedPath)
        } catch (error) {
          // Another DSH profile may have populated the same immutable cache while
          // this process was copying. Its complete file is safe to reuse.
          if (!fileExists(cachedPath) || fileStat(cachedPath).size !== sourceSize) throw error
        }
      } else if (fileStat(cachedPath).size !== sourceSize) {
        removeFile(cachedPath)
        moveFile(temporaryPath, cachedPath)
      }
    } finally {
      if (fileExists(temporaryPath)) removeFile(temporaryPath)
    }
  }
  if (!fileExists(cachedManifest)) copyTree(assetsSource, resolve(cacheDirectory, 'assets'), { recursive: true })
  return cachedPath
}

function resolveHelperLaunch({
  platform,
  arch = process.arch,
  isWslEnv,
  bundledPath,
  linuxBundledPath = linuxBundledHelperPath,
  linuxArm64BundledPath = linuxArm64BundledHelperPath,
  darwinBundledPath = darwinBundledHelperPath,
  helperPath,
  pythonEnv,
  headless = false,
  fileExists = existsSync,
  windowsPath = toWindowsPath,
  cmdExe = defaultCmdExe,
  wslHelperCache = cacheWslBundledHelper,
}) {
  if (platform === 'win32' && fileExists(bundledPath)) {
    // Run the versioned Windows-local copy when the cache is available. The
    // plugin directory then never holds a running executable, so a plugin
    // update can replace node_modules/dsh-dafeiyu while DSH is still open
    // (issue #66: pnpm rename failed with EPERM on the locked directory).
    try {
      return { command: wslHelperCache({ bundledPath }), args: [] }
    } catch {
      return { command: bundledPath, args: [] }
    }
  }
  if (platform === 'darwin' && fileExists(darwinBundledPath)) {
    return { command: darwinBundledPath, args: [] }
  }
  if (platform === 'linux' && isWslEnv && !headless && fileExists(bundledPath)) {
    // npm archives created on Windows store ordinary files as 0644. Launching
    // the EXE directly from WSL can therefore fail with EACCES. cmd.exe opens
    // the Windows path without relying on the Linux executable bit and keeps
    // stdin/stdout attached for the companion protocol.
    let launchPath = bundledPath
    try {
      // Running a PyInstaller one-file EXE directly from \\wsl.localhost makes
      // Windows read and unpack the archive through the WSL file bridge. That
      // can saturate the WSL VM whenever the plugin starts or is re-enabled.
      // Cache one immutable copy on the Windows filesystem and reuse it.
      launchPath = wslHelperCache({ bundledPath })
    } catch {
      // Cache preparation is an optimization. Keep the existing UNC launch as
      // a compatibility fallback for locked-down or unusual WSL installs.
    }
    return {
      command: cmdExe(),
      args: ['/d', '/c', windowsPath(launchPath)],
    }
  }
  if (platform === 'linux') {
    const bundled = linuxHelperForArch(arch, { x64: linuxBundledPath, arm64: linuxArm64BundledPath })
    if (bundled !== undefined && fileExists(bundled)) {
      return { command: bundled, args: [] }
    }
    const command = pythonEnv || 'python3'
    // Only mention an architecture mismatch when a Helper for another
    // architecture is present. A trimmed source checkout simply has no bundle.
    const bundledForOtherArch = [
      ['x64', linuxBundledPath],
      ['arm64', linuxArm64BundledPath],
    ].some(([candidate, path]) => candidate !== arch && fileExists(path))
    const launch = { command, args: defaultArgs(command, helperPath) }
    if (bundledForOtherArch) {
      launch.notice = `no bundled Helper for linux/${arch}; falling back to ${command} (install PySide6 or use a release with a linux/${arch} Helper)`
    }
    return launch
  }
  const command = pythonEnv || (platform === 'win32' ? 'py' : 'python3')
  return { command, args: defaultArgs(command, helperPath) }
}

function defaultLaunch(headless = false) {
  return resolveHelperLaunch({
    platform: process.platform,
    arch: process.arch,
    isWslEnv: isWsl(),
    bundledPath: bundledHelperPath,
    linuxBundledPath: linuxBundledHelperPath,
    darwinBundledPath: darwinBundledHelperPath,
    helperPath: defaultHelperPath,
    pythonEnv: process.env.DSH_DAFEIYU_PYTHON,
    headless,
  })
}

function defaultCommand(headless = false) {
  return defaultLaunch(headless).command
}

function defaultArgs(command, helperPath) {
  if (isBundledHelperCommand(command)) return []
  if (process.platform === 'win32' && /(^|[\\/])py(?:\.exe)?$/i.test(command)) {
    return ['-3', helperPath]
  }
  return [helperPath]
}

export function resolveHelperEnvironment(environment = process.env, overrides = {}) {
  const env = { ...environment, ...overrides }
  // Desktop's Host runs Electron as Node. Native helpers must not pass that
  // mode to applications launched through QDesktopServices / NSWorkspace.
  for (const key of Object.keys(env)) {
    if (key.toUpperCase() === 'ELECTRON_RUN_AS_NODE') delete env[key]
  }
  return env
}

function withHelperTempDirectory(environment, directory) {
  // Windows environment names are case-insensitive; drop every spelling before
  // setting the canonical uppercase variables so the child cannot inherit a
  // stale Temp/TMP from the Host.
  for (const key of Object.keys(environment)) {
    const upper = key.toUpperCase()
    if (upper === 'TEMP' || upper === 'TMP' || upper === 'TMPDIR') delete environment[key]
  }
  environment.TEMP = directory
  environment.TMP = directory
  environment.TMPDIR = directory
  return environment
}

export class HelperProcess {
  constructor(options = {}, logger = console) {
    this.options = options
    this.logger = logger
    this.child = undefined
    this.queue = []
    this.snapshot = new Map()
    this.spawned = false
    this.hasEverSpawned = false
    this.stopping = false
    this.restartSuppressed = false
    this.startFailures = 0
    this.restartTimer = undefined
    this.heartbeatTimer = undefined
    this.startupTimer = undefined
    this.lastPongAt = 0
    this.lastStartAt = 0
    this.readyAt = 0
    this.writeBlocked = false
    this.queueDropWarned = false
    this.startAttempts = 0
    this.launchNoticeLogged = false
    this.launchHintLogged = false
    this.pythonHintLogged = false
    this.tempPrepared = false
    // An explicit command means tests or a custom launcher: do not touch the
    // user's temp directory or log file unless the caller asks for it.
    this.tempDirectory = this.options.tempDirectory !== undefined
      ? this.options.tempDirectory
      : (this.options.command || isWsl() ? undefined : defaultHelperTempDirectory())
    this.log = this.options.logFile !== undefined
      ? createHelperLog(this.options.logFile)
      : createHelperLog(this.options.command ? undefined : defaultHelperLogPath())
  }

  start() {
    if (this.child || this.stopping || this.restartSuppressed) return this.child
    // Resolving the launch command can throw synchronously (e.g. WSL interop
    // probing). Never let that escape: it would crash the host when it happens
    // inside the restart timer. Treat it like any other start failure instead.
    let child
    let startupTimeoutMs
    try {
      this.startAttempts += 1
      this.lastStartAt = Date.now()
      const headless = this.options.headless ?? process.env.DSH_DAFEIYU_HEADLESS === '1'
      const helperPath = this.options.helperPath || defaultHelperPath
      const launch = this.options.command
        ? { command: this.options.command, args: defaultArgs(this.options.command, helperPath) }
        : defaultLaunch(headless)
      const command = launch.command
      const args = this.options.args || launch.args
      if (process.platform !== 'win32' && isBundledHelperCommand(command)) {
        ensureExecutable(command)
      }
      const extraArgs = []
      const eventLog = this.options.eventLog || process.env.DSH_DAFEIYU_EVENT_LOG
      const snapshot = this.options.snapshot || process.env.DSH_DAFEIYU_SNAPSHOT
      if (headless) extraArgs.push('--headless')
      if (eventLog) extraArgs.push('--event-log', eventLog)
      if (snapshot) extraArgs.push('--snapshot', snapshot)

      if (launch.notice && !this.launchNoticeLogged) {
        this.launchNoticeLogged = true
        this.logger.warn?.(`dsh-dafeiyu ${launch.notice}`)
        this.#log('WARN', launch.notice)
      }
      if (this.startAttempts === 1) {
        this.#log('INFO', `Helper diagnostics: plugin=${packageVersion}, node=${process.version}, host=${process.platform}/${process.arch}`)
      }
      startupTimeoutMs = this.#startupTimeoutMs()
      this.#log('INFO', `start attempt ${this.startAttempts}: ${command} ${[...args, ...extraArgs].join(' ')} (startupTimeoutMs=${startupTimeoutMs}, temp=${this.tempDirectory ?? 'system'})`)

      const environment = resolveHelperEnvironment(process.env, this.options.env)
      if (this.tempDirectory) {
        this.#prepareTempDirectory()
        // PyInstaller's one-file bootloader extracts to `_MEI*` under these
        // variables. Keeping them in the plugin cache makes the leftovers
        // reclaimable instead of scattering gigabytes through %TEMP%.
        withHelperTempDirectory(environment, this.tempDirectory)
      }

      child = spawn(command, [...args, ...extraArgs], {
        cwd: this.options.cwd || resolve(here, '..'),
        env: environment,
        stdio: ['pipe', 'pipe', 'pipe'],
        windowsHide: true,
      })
    } catch (error) {
      this.child = undefined
      this.spawned = false
      this.logger.error?.(`dsh-dafeiyu helper failed to start: ${error.message}`)
      this.#log('ERROR', `launch error: ${error.message}`)
      if (!this.stopping && !this.restartSuppressed) {
        this.#countStartFailure(`launch error: ${error.message}`)
      }
      return undefined
    }
    this.child = child
    // A broken pipe on any child channel must never crash the DSH host.
    // EPIPE on stdin is expected after the helper dies before we flush.
    child.stdin.on('error', () => {})
    child.stdout.on('error', () => {})
    child.stderr.on('error', () => {})
    child.once('spawn', () => {
      this.#log('INFO', `spawned pid=${String(child.pid)}`)
      this.startupTimer = setTimeout(() => {
        if (this.child === child && !this.spawned) {
          const diagnostics = this.log?.path ? `; diagnostics: ${this.log.path}` : ''
          this.logger.warn?.(`dsh-dafeiyu helper readiness timed out after ${startupTimeoutMs}ms${diagnostics}`)
          this.#log('ERROR', `readiness timed out after ${startupTimeoutMs}ms; killing helper pid=${String(child.pid)}`)
          child.kill()
        }
      }, startupTimeoutMs)
      this.startupTimer.unref?.()
    })
    child.once('error', (error) => {
      this.logger.error?.(`dsh-dafeiyu helper failed to start: ${error.message}`)
      this.#log('ERROR', `spawn error: ${error.message}`)
      if (!this.launchHintLogged && error.code === 'ENOENT') {
        this.launchHintLogged = true
        const hint = `dsh-dafeiyu Helper launch command was not found. If the Python fallback was selected, install python3 and "PySide6>=6.7,<7" for ${process.platform}/${process.arch}.`
        this.logger.error?.(hint)
        this.#log('ERROR', hint)
      }
      if (this.child !== child) return
      this.child = undefined
      this.spawned = false
      this.readyAt = 0
      this.writeBlocked = false
      this.#clearHeartbeat()
      this.#clearStartupTimer()
      if (!this.stopping && !this.restartSuppressed) {
        this.#countStartFailure(`spawn error: ${error.message}`)
      }
    })
    child.once('exit', (code, signal) => {
      if (this.child !== child) return
      this.#log('INFO', `helper exited code=${String(code)} signal=${String(signal)} ready=${String(this.spawned)} runtimeMs=${this.readyAt > 0 ? Date.now() - this.readyAt : 0}`)
      this.child = undefined
      const wasReady = this.spawned
      const readyAt = this.readyAt
      this.spawned = false
      this.readyAt = 0
      this.writeBlocked = false
      this.#clearHeartbeat()
      this.#clearStartupTimer()
      if (!this.stopping && !this.restartSuppressed) {
        if (!wasReady) {
          // The helper never became ready during this attempt (crashed before
          // READY or timed out). Count it as a failed start so a broken
          // helper cannot restart forever.
          this.#countStartFailure(`exited before ready (code=${String(code)}, signal=${String(signal)})`)
          return
        }
        const stableRuntimeMs = this.options.stableRuntimeMs ?? 30000
        const runtimeMs = readyAt > 0 ? Date.now() - readyAt : 0
        if (runtimeMs < stableRuntimeMs) {
          this.#countStartFailure(`exited ${runtimeMs}ms after ready (code=${String(code)}, signal=${String(signal)})`)
          return
        }
        this.startFailures = 0
        this.logger.warn?.(`dsh-dafeiyu helper exited (code=${String(code)}, signal=${String(signal)}); restarting`)
        this.#scheduleRestart()
      }
    })
    createInterface({ input: child.stdout }).on('line', (line) => this.#handleReply(line))
    createInterface({ input: child.stderr }).on('line', (line) => {
      if (!line.trim()) return
      this.logger.warn?.(`dsh-dafeiyu helper: ${line}`)
      this.#log('WARN', `helper stderr: ${line.slice(0, 2000)}`)
      // The Python fallback is a supported path on architectures without a
      // bundled Helper; name the missing package instead of leaving only a
      // traceback in a console the user may never see (issue #91).
      // helper.py catches ImportError itself and prints
      // "PySide6 is required for visual mode (...)", so the exception class
      // name is not part of that supported fallback message.
      if (!this.pythonHintLogged
        && /(?:ModuleNotFoundError|ImportError).*PySide6|PySide6 is required for visual mode/.test(line)) {
        this.pythonHintLogged = true
        const hint = `dsh-dafeiyu fell back to the Python Helper but PySide6 is unavailable. Install "PySide6>=6.7,<7" for ${process.platform}/${process.arch}, or install a release that bundles a Helper for this architecture.`
        this.logger.error?.(hint)
        this.#log('ERROR', hint)
      }
    })
    return child
  }

  send(message) {
    this.#remember(message)
    const line = encodeMessage(message)
    if (!this.child || !this.spawned || !this.child.stdin.writable || this.child.stdin.destroyed) {
      if (!this.hasEverSpawned
        || !coalescibleMessageKinds.has(message.kind)) {
        this.#enqueue(message.kind, line)
      }
      return
    }
    if (this.writeBlocked) {
      this.#enqueue(message.kind, line)
      return
    }
    this.#writePayload(this.child, line)
  }

  stop(reason = 'plugin-disposed') {
    this.#log('INFO', `stop requested (${reason})`)
    this.stopping = true
    this.#clearHeartbeat()
    if (this.restartTimer) clearTimeout(this.restartTimer)
    this.restartTimer = undefined
    const child = this.child
    if (!child) return
    this.#enqueue(
      CompanionMessageKind.SHUTDOWN,
      encodeMessage(createMessage(CompanionMessageKind.SHUTDOWN, { reason })),
    )
    if (this.spawned) {
      this.#flushQueue()
      this.#endInput(child)
    }
    const timer = setTimeout(() => {
      if (this.child === child) child.kill()
    }, this.options.shutdownTimeoutMs ?? 10000)
    timer.unref?.()
  }

  #remember(message) {
    if (message.kind === CompanionMessageKind.HELLO) this.snapshot.set('hello', encodeMessage(message))
    if (message.kind === CompanionMessageKind.STATE) this.snapshot.set('state', encodeMessage(message))
    if (message.kind === CompanionMessageKind.TASK) this.snapshot.set('task', encodeMessage(message))
    if (message.kind === CompanionMessageKind.TASKS) this.snapshot.set('tasks', encodeMessage(message))
    if (message.kind === CompanionMessageKind.CONFIG) this.snapshot.set('config', encodeMessage(message))
    if (message.kind === CompanionMessageKind.BALANCE) this.snapshot.set('balance', encodeMessage(message))
  }

  #flushSnapshot() {
    const child = this.child
    if (this.writeBlocked || !this.spawned || !child?.stdin.writable || child.stdin.destroyed) return
    const payload = [...this.snapshot.values()].join('')
    if (payload) this.#writePayload(child, payload)
  }

  #flushQueue() {
    const child = this.child
    if (this.writeBlocked || !this.spawned || !child?.stdin.writable || child.stdin.destroyed) return
    const payload = this.queue.splice(0).map((item) => item.line).join('')
    if (payload) this.#writePayload(child, payload)
  }

  #enqueue(kind, line) {
    if (kind === CompanionMessageKind.PING) return
    const maxPendingMessages = Math.max(1, this.options.maxPendingMessages ?? 128)
    if (this.queue.length >= maxPendingMessages) {
      const sameKind = coalescibleMessageKinds.has(kind)
        ? this.queue.findIndex((item) => item.kind === kind)
        : -1
      this.queue.splice(sameKind >= 0 ? sameKind : 0, 1)
      if (!this.queueDropWarned) {
        this.queueDropWarned = true
        this.logger.warn?.(`dsh-dafeiyu helper message queue reached ${maxPendingMessages}; dropping stale updates`)
      }
    }
    this.queue.push({ kind, line })
  }

  #writePayload(child, payload) {
    if (!payload || this.child !== child || !child.stdin.writable || child.stdin.destroyed) return
    if (child.stdin.write(payload)) return
    this.writeBlocked = true
    child.stdin.once('drain', () => {
      if (this.child !== child || !this.spawned) return
      this.writeBlocked = false
      this.queueDropWarned = false
      this.#flushQueue()
    })
  }

  #handleReply(line) {
    if (!line.trim()) return
    try {
      const reply = JSON.parse(line)
      if (reply?.protocolVersion === 1 && reply.kind === CompanionMessageKind.READY) {
        if (this.spawned) return
        const firstSpawn = !this.hasEverSpawned
        this.hasEverSpawned = true
        this.spawned = true
        this.readyAt = Date.now()
        this.lastPongAt = Date.now()
        this.#log('INFO', `ready after ${String(this.lastStartAt ? this.readyAt - this.lastStartAt : 0)}ms`)
        this.#clearStartupTimer()
        if (firstSpawn) this.#flushQueue()
        else {
          this.#flushSnapshot()
          this.#flushQueue()
        }
        this.#startHeartbeat()
        if (this.stopping) this.#endInput(this.child)
        return
      }
      if (reply?.protocolVersion === 1 && reply.kind === CompanionMessageKind.PONG) {
        this.lastPongAt = Date.now()
        return
      }
      if (reply?.protocolVersion === 1 && reply.kind === CompanionMessageKind.CLOSED) {
        this.restartSuppressed = true
        return
      }
      if (reply?.protocolVersion === 1 && reply.kind === CompanionMessageKind.SETTINGS) {
        this.options.onSettingsChange?.(reply)
        return
      }
      if (reply?.protocolVersion === 1 && reply.kind === CompanionMessageKind.CHAT) {
        this.options.onChat?.({
          text: typeof reply.text === 'string' ? reply.text : '',
          mode: reply.mode === 'task' ? 'task' : 'chat',
        })
        return
      }
    } catch {
      // Non-protocol stdout is still useful in development logs.
    }
    this.logger.debug?.(`dsh-dafeiyu helper: ${line}`)
  }

  #startHeartbeat() {
    const heartbeatMs = this.options.heartbeatMs ?? 5000
    if (heartbeatMs <= 0) return
    const timeoutMs = this.options.heartbeatTimeoutMs ?? Math.max(heartbeatMs * 3, 12000)
    this.heartbeatTimer = setInterval(() => {
      const child = this.child
      if (!child || !this.spawned) return
      if (Date.now() - this.lastPongAt > timeoutMs) {
        this.logger.warn?.('dsh-dafeiyu helper heartbeat timed out')
        this.#log('ERROR', `heartbeat timed out after ${String(Date.now() - this.lastPongAt)}ms; killing helper`)
        child.kill()
        return
      }
      this.send(createMessage(CompanionMessageKind.PING))
    }, heartbeatMs)
    this.heartbeatTimer.unref?.()
  }

  #clearHeartbeat() {
    if (this.heartbeatTimer) clearInterval(this.heartbeatTimer)
    this.heartbeatTimer = undefined
  }

  #clearStartupTimer() {
    if (this.startupTimer) clearTimeout(this.startupTimer)
    this.startupTimer = undefined
  }

  #startupTimeoutMs() {
    if (this.options.startupTimeoutMs !== undefined) return this.options.startupTimeoutMs
    if (this.hasEverSpawned) return WARM_START_TIMEOUT_MS
    // Only the very first attempt pays the one-file extraction and cold
    // antivirus scan. Later retries reuse whatever the first attempt cached.
    if (this.startAttempts <= 1) return COLD_START_TIMEOUT_MS
    return RESTART_START_TIMEOUT_MS
  }

  #prepareTempDirectory() {
    if (this.tempPrepared) return
    this.tempPrepared = true
    try {
      mkdirSync(this.tempDirectory, { recursive: true })
      const removed = cleanStaleExtractionDirectories(this.tempDirectory)
      if (removed.length > 0) {
        this.#log('INFO', `removed ${removed.length} stale Helper extraction director${removed.length === 1 ? 'y' : 'ies'} from ${this.tempDirectory}`)
      }
    } catch (error) {
      this.#log('WARN', `unable to prepare Helper temp directory ${this.tempDirectory}: ${error instanceof Error ? error.message : String(error)}`)
    }
  }

  #log(level, message) {
    this.log?.write(level, message)
  }

  #countStartFailure(reason) {
    this.startFailures += 1
    const maxFailures = this.options.maxStartFailures ?? 5
    this.#log('ERROR', `start failure ${this.startFailures}/${maxFailures}: ${reason}`)
    if (this.startFailures >= maxFailures) {
      this.restartSuppressed = true
      const diagnostics = this.log?.path ? `; diagnostics: ${this.log.path}` : ''
      this.logger.error?.(`dsh-dafeiyu helper failed to start ${this.startFailures} times; giving up (${reason})${diagnostics}`)
      this.#log('ERROR', `giving up after ${this.startFailures} failed starts; the companion stays disabled until the next DSH start`)
      return
    }
    this.logger.warn?.(`dsh-dafeiyu helper failed to start; scheduling restart (${this.startFailures}/${maxFailures}) (${reason})`)
    this.#scheduleRestart()
  }

  #scheduleRestart() {
    if (this.restartTimer || this.stopping || this.restartSuppressed) return
    const delay = this.options.restartDelayMs ?? 750
    this.restartTimer = setTimeout(() => {
      this.restartTimer = undefined
      this.start()
    }, delay)
    this.restartTimer.unref?.()
  }

  #endInput(child) {
    if (child.stdin.writable && !child.stdin.destroyed) child.stdin.end()
  }
}

export {
  COLD_START_TIMEOUT_MS,
  RESTART_START_TIMEOUT_MS,
  WARM_START_TIMEOUT_MS,
  bundledHelperPath,
  cleanStaleExtractionDirectories,
  darwinBundledHelperPath,
  defaultHelperPath,
  defaultHelperTempDirectory,
  defaultArgs,
  defaultCmdExe,
  defaultCommand,
  defaultLaunch,
  defaultWindowsLocalAppData,
  defaultLocalAppData,
  cacheWslBundledHelper,
  isBundledHelperCommand,
  isWsl,
  linuxArm64BundledHelperPath,
  linuxBundledHelperPath,
  linuxHelperForArch,
  resolveHelperLaunch,
  shouldUseBundledHelper,
  toWindowsPath,
}
