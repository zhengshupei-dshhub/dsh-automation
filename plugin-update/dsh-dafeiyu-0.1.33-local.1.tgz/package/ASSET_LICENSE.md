# Visual asset notice

The source code in this repository is MIT-licensed. The visual character
assets currently bundled under `assets/pet/` are MIT-licensed as well and
originate from the [dsh-pet](https://github.com/PC2005-cloud/dsh-pet) project;
see the "Whale-tail maid character assets" section below. The previous BigFish
frames remain archived under `legacy/dafeiyu/` under their original
restricted terms; see the "Legacy BigFish frames" section.

## Whale-tail maid character assets (current, MIT)

The runtime frames under `assets/pet/` are converted from the animation set of
[PC2005-cloud/dsh-pet](https://github.com/PC2005-cloud/dsh-pet)
(`assets/webm/`, Copyright (c) 2026 PC2005-cloud), which that project
distributes under the MIT license together with its AI-generation prompt
recipes. The source clips are AI-generated green-screen animations matted to
transparent VP9 WebM; this repository re-encodes the selected clips at their native 24 fps as
transparent WebP frame sequences on one shared crop window (see
`scripts/import_dshpet_webm.py`).

The current import is pinned to upstream commit
[`549fff2ea33c2acfb16612c76912c6137da4a758`](https://github.com/PC2005-cloud/dsh-pet/tree/549fff2ea33c2acfb16612c76912c6137da4a758/dsh-pet/assets/webm).
`assets/pet-manifest.json` records each source video's SHA-256 and exact frame
window, plus the common crop and encoding settings. Touch and idle actions
retain the complete source entrance and exit; the dragging / landing clips
split one source into its suspended loop and complete return to rest. Stretch
and yawn frames come from the same upstream set. No runtime character clip
uses the archived BigFish frames or a procedural dizzy pose.

They remain subject to the upstream MIT license, bundled verbatim as
`assets/dsh-pet-LICENSE.txt` and shipped in the npm package. No warranty is
given; the "dsh-pet" name and its project identity belong to their respective
owners.

## Legacy BigFish frames (archived, restricted)

The frames previously bundled under `assets/pet/` now live under
`legacy/dafeiyu/`. The source code in this repository is MIT-licensed;
those BigFish visual character assets are **not covered by the MIT code
license**.

These 238px runtime PNG frames (now archived under `legacy/dafeiyu/`,
excluded from the npm bundle) were copied from the formal runtime output of
`QCYTSN/ds-local-pet` at local release `v0.2.0`. They are derived from a mixture
of fan-made DeepSeek-related character views and AI-assisted animation sheets.
Image processing, resizing, or repackaging does not change rights in the
underlying artwork. No additional license or warranty is granted for these
visual files. The four community-contributed dragging poses live under
`legacy/dafeiyu/dragging/`.

The plugin does not include source references, paid pose references, candidate
sheets, or original working material. Only the explicitly allowlisted runtime
frames required by the DSH companion are bundled.

The notification sounds under `assets/sounds/` are original procedural audio
generated for this repository by `scripts/generate_notification_sounds.py`.
They contain no third-party recordings and are covered by the repository's MIT
license.

The glove status cursors `assets/cursor_grab.cur` (open hand) and
`assets/cursor_grabbing.cur` (closed fist) are **unmodified copies** of the
cursor images shipped by the Chromium project in
`ui/resources/cursors/` (`hand_grab.cur`, `hand_grabbing.cur`, 32x32).
They are licensed under the **BSD 3-Clause license** held by The Chromium
Authors and are **not covered by the MIT code license**; both licenses are
permissive and compatible. The upstream license text and a provenance note
with the upstream URLs and file digests are bundled in `assets/cursors/`
(`LICENSE`, `README.md`), and the digests are pinned by the test suite.

This is an unofficial fan-made project and is not affiliated with or endorsed
by DeepSeek. Names, marks, and character-related rights belong to their
respective owners.

Source provenance and the fuller notice are documented in:

- https://github.com/QCYTSN/ds-local-pet/blob/main/ASSET_LICENSE.md
- https://github.com/1190fasheqi/dafeiyu-pet

## Community-contributed dragging frames (archived with the legacy set)

The four frames under `legacy/dafeiyu/dragging/` (`dragging_238_01.png`,
`dragging_238_02.png`, `dragging_238_03.png`, and `dragging_238_04.png`: held,
released, dizzy, and protest poses) were contributed to this repository by
`@Serendipity-wu02`. They are original AI-assisted artwork created for the
BigFish companion; no third-party, paid, or scraped material is included. The
uploaded source images were uniformly rescaled and letterboxed onto the
238x260 runtime canvas by automated processing only, which does not change
rights in the underlying artwork.

These frames replace the previous single `dragging/dragging_238.png` frame
and are distributed under the same terms as the other visual assets above:
they are bundled solely for use with this fan-made companion plugin, carry
no separate warranty, and remain excluded from the MIT code license.
Redistribution outside this repository requires permission from the
respective rights holders.
