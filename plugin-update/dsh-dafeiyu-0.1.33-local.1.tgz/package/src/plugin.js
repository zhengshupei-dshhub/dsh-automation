import { createRequire } from 'node:module'
import { readFileSync } from 'node:fs'
import { dirname, join, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import Schema from '@deepseek-ai/schemastery'
import { CompanionReducer } from './companion-reducer.js'
import { createPersonaBridge } from './persona-bridge.js'
import { bubblePreview, buildFollowupMessage, extractAssistantText } from './chat.js'
import { HelperProcess } from './helper-process.js'
import { createSettingsScope } from './settings-scope.js'
import { createHelperLog, defaultHelperLogPath } from './helper-log.js'
import { createUserSettingsStore, defaultUserSettingsPath } from './user-settings.js'
import { resolveClientTarget } from './client-target.js'
import { isLocalRequest, jsonResponse } from './local-http.js'
import { BALANCE_ENDPOINT, createBalanceQuery, createBalanceMonitor, createBalanceHandler, balanceProviderNamespace } from './balance.js'
import {
  CompanionMessageKind,
  CompanionState,
  createMessage,
} from './protocol.js'

const require = createRequire(import.meta.url)
const pkg = require('../package.json')

export const name = 'dsh-dafeiyu'
// The plugin's feature is built on session events, and mounting requires the
// settings service (used to read live config). Keep the declared inject in
// sync with those real hard dependencies instead of listing a service that
// is never consumed directly.
export const inject = ['sessions', 'settings']
export const CONFIG_ENDPOINT = '/plugins/dsh-dafeiyu/config'
export const EVENTS_ENDPOINT = '/plugins/dsh-dafeiyu/events'
export const MANIFEST_ENDPOINT = '/plugins/dsh-dafeiyu/manifest'
export const FRAME_ENDPOINT = '/plugins/dsh-dafeiyu/frame'
export { BALANCE_ENDPOINT }

const here = dirname(fileURLToPath(import.meta.url))
const assetsRoot = resolve(here, '..', 'assets')
export const Config = Schema.object({
  enabled: Schema.boolean().default(true).description('启用桌面大肥鱼'),
  scale: Schema.number().min(0.55).max(1.4).step(0.05).default(1).role('slider').description('角色大小'),
  bubbleScale: Schema.number().min(0.5).max(1.2).step(0.05).default(1).role('slider').description('气泡大小'),
  activityLevel: Schema.union([
    Schema.const('quiet').description('安静'),
    Schema.const('normal').description('标准'),
    Schema.const('lively').description('活泼'),
  ]).default('normal').description('空闲微动作频率'),
  reducedMotion: Schema.boolean().default(false).description('减少走动、循环帧和程序化晃动'),
  soundEnabled: Schema.boolean().default(true).description('任务完成或出错时播放提示音'),
  soundStates: Schema.array(Schema.union([
    Schema.const('SUCCESS').description('对话完成'),
    Schema.const('ERROR').description('工具出错'),
    Schema.const('APPROVAL').description('等待审批'),
  ])).role('checkbox').default(['SUCCESS', 'ERROR']).description('播放提示音与系统通知的场景'),
  bubbleMode: Schema.union([
    Schema.const('always').description('常驻显示'),
    Schema.const('hidden').description('完全隐藏'),
    Schema.const('custom').description('自定义显示状态'),
  ]).default('always').description('气泡显示模式'),
  bubbleStates: Schema.array(Schema.string()).default(['SUCCESS', 'ERROR', 'WAITING']).description('自定义模式下显示气泡的状态'),
  lookTheme: Schema.union([
    Schema.const('auto').description('跟随季节'),
    Schema.const('spring').description('春'),
    Schema.const('summer').description('夏'),
    Schema.const('autumn').description('秋'),
    Schema.const('winter').description('冬'),
    Schema.const('off').description('关闭'),
  ]).default('auto').description('季节皮肤：角色背后的光晕与飘落粒子（不改精灵图）'),
  lookIntensity: Schema.number().min(0).max(1).step(0.05).default(0.35).role('slider').description('季节皮肤强度'),
  includeSubagents: Schema.boolean().default(false).description('允许子 Agent 抢占宠物状态'),
  webOverlay: Schema.boolean().default(false).description('在 DSH 页面右下角显示轻量桌宠（可与桌面窗口同时开启）'),
  clientTarget: Schema.union(['auto', 'web', 'desktop']).default('auto').description('打开 DSH 的目标客户端（自动识别 WebUI／桌面端）'),
  balanceEnabled: Schema.boolean().default(true).description('在状态气泡和设置页显示 DeepSeek 余额'),
  balanceSource: Schema.union(['auto', 'api-key', 'account']).default('auto').description('余额来源：自动优先 API Key，也可选择已登录账户'),
  personaEnabled: Schema.boolean().default(true).description('人设成长时让大肥鱼冒泡'),
  personaIdleMinutes: Schema.number().min(5).max(120).step(5).default(20).role('slider').description('空闲多久可以自言自语（分钟）'),
  personaDir: Schema.string().default('').description('人设数据目录，留空使用 $DSH_HOME/memory'),
}).description('由 DeepSeek Harness 状态驱动的桌面大肥鱼伴侣')

// Mark fields, rather than the root object: current DSH passes each volatile
// field as a live reference, while the config object remains an object.
for (const [key, field] of Object.entries(Config.dict)) Config.dict[key] = field.volatile()

const defaults = Object.freeze({
  enabled: true,
  scale: 1,
  bubbleScale: 1,
  activityLevel: 'normal',
  reducedMotion: false,
  soundEnabled: true,
  soundStates: ['SUCCESS', 'ERROR'],
  bubbleMode: 'always',
  bubbleStates: ['SUCCESS', 'ERROR', 'WAITING'],
  lookTheme: 'auto',
  lookIntensity: 0.35,
  includeSubagents: false,
  webOverlay: false,
  clientTarget: 'auto',
  balanceEnabled: true,
  balanceSource: 'auto',
  personaEnabled: true,
  personaIdleMinutes: 20,
  personaDir: '',
})

const SOUND_STATES = new Set(['SUCCESS', 'ERROR', 'APPROVAL'])

export function normalizeSoundStates(value) {
  if (!Array.isArray(value)) return [...defaults.soundStates]
  return [...new Set(value.filter((state) => SOUND_STATES.has(state)))]
}

function publicConfig(config = {}) {
  return {
    enabled: config.enabled ?? defaults.enabled,
    scale: config.scale ?? defaults.scale,
    bubbleScale: config.bubbleScale ?? defaults.bubbleScale,
    activityLevel: config.activityLevel ?? defaults.activityLevel,
    reducedMotion: config.reducedMotion ?? defaults.reducedMotion,
    soundEnabled: config.soundEnabled ?? defaults.soundEnabled,
    soundStates: normalizeSoundStates(config.soundStates),
    bubbleMode: config.bubbleMode ?? defaults.bubbleMode,
    bubbleStates: Array.isArray(config.bubbleStates) ? config.bubbleStates : defaults.bubbleStates,
    lookTheme: config.lookTheme ?? defaults.lookTheme,
    lookIntensity: config.lookIntensity ?? defaults.lookIntensity,
    includeSubagents: config.includeSubagents ?? defaults.includeSubagents,
    webOverlay: config.webOverlay === true,
    clientTarget: config.clientTarget ?? defaults.clientTarget,
    balanceEnabled: config.balanceEnabled !== false,
    balanceSource: config.balanceSource ?? defaults.balanceSource,
    personaEnabled: config.personaEnabled !== false,
    personaIdleMinutes: config.personaIdleMinutes ?? defaults.personaIdleMinutes,
    personaDir: config.personaDir ?? '',
  }
}

async function readPatch(req) {
  const chunks = []
  let bytes = 0
  for await (const chunk of req) {
    bytes += chunk.length
    if (bytes > 8192) throw new Error('request body is too large')
    chunks.push(chunk)
  }
  const value = JSON.parse(Buffer.concat(chunks).toString('utf8'))
  if (value === null || typeof value !== 'object' || Array.isArray(value)) throw new Error('patch must be an object')
  const allowed = new Set(Object.keys(defaults))
  if (Object.keys(value).some((key) => !allowed.has(key))) throw new Error('patch contains an unknown setting')
  if ('soundStates' in value) {
    if (!Array.isArray(value.soundStates)) throw new Error('soundStates must be an array')
    value.soundStates = normalizeSoundStates(value.soundStates)
  }
  return value
}

export function createConfigHandler(settings) {
  return async (req, res) => {
    if (!isLocalRequest(req)) {
      jsonResponse(res, 403, { error: 'local access only' })
      return
    }
    if (req.method === 'GET') {
      jsonResponse(res, 200, settings.get())
      return
    }
    if (req.method !== 'PATCH') {
      jsonResponse(res, 405, { error: 'method not allowed' })
      return
    }
    if (typeof settings.update !== 'function') {
      jsonResponse(res, 503, { error: 'settings are read-only; restart DSH or use a supported host version' })
      return
    }
    try {
      await settings.update(await readPatch(req))
      jsonResponse(res, 200, settings.get())
    } catch (error) {
      jsonResponse(res, 400, { error: error instanceof Error ? error.message : String(error) })
    }
  }
}

// Server-sent events channel mirroring the companion protocol for in-page
// consumers (the future web overlay). Snapshot kinds are remembered so a client
// that connects late still renders the current state immediately.
export function createEventStream() {
  const clients = new Set()
  const snapshot = new Map()
  return {
    get clientCount() {
      return clients.size
    },
    broadcast(message) {
      if (message?.kind === 'hello' || message?.kind === 'state' || message?.kind === 'task'
        || message?.kind === 'tasks' || message?.kind === 'config' || message?.kind === 'balance') {
        snapshot.set(message.kind, message)
      }
      const payload = `data: ${JSON.stringify(message)}\n\n`
      for (const res of clients) {
        try {
          res.write(payload)
        } catch {
          clients.delete(res)
        }
      }
    },
    add(res) {
      clients.add(res)
      for (const message of snapshot.values()) {
        res.write(`data: ${JSON.stringify(message)}\n\n`)
      }
      return () => clients.delete(res)
    },
  }
}

export function createEventsHandler(stream) {
  return (req, res) => {
    if (!isLocalRequest(req)) {
      jsonResponse(res, 403, { error: 'local access only' })
      return
    }
    res.writeHead(200, {
      'content-type': 'text/event-stream; charset=utf-8',
      'cache-control': 'no-store',
      connection: 'keep-alive',
    })
    res.write('retry: 2000\n\n')
    const remove = stream.add(res)
    req.on('close', remove)
  }
}

// Frame bytes are served only for paths the manifest declares, so the query
// parameter can never steer the reader outside assets/pet. Returns null when
// the manifest cannot be read; the overlay routes then stay unregistered.
export function createAssetRoutes() {
  let manifest
  try {
    manifest = JSON.parse(readFileSync(join(assetsRoot, 'pet-manifest.json'), 'utf8'))
  } catch {
    return null
  }
  const frames = new Set()
  for (const clip of Object.values(manifest.clips ?? {})) {
    for (const frame of clip.frames ?? []) frames.add(frame)
  }
  return {
    manifestHandler(req, res) {
      if (!isLocalRequest(req)) {
        jsonResponse(res, 403, { error: 'local access only' })
        return
      }
      jsonResponse(res, 200, manifest)
    },
    frameHandler(req, res) {
      if (!isLocalRequest(req)) {
        jsonResponse(res, 403, { error: 'local access only' })
        return
      }
      let frame
      try {
        frame = new URL(req.url ?? '', 'http://dsh.local').searchParams.get('frame')
      } catch {
        frame = null
      }
      if (!frame || !frames.has(frame)) {
        jsonResponse(res, 404, { error: 'unknown frame' })
        return
      }
      let bytes
      try {
        bytes = readFileSync(join(assetsRoot, 'pet', frame))
      } catch {
        jsonResponse(res, 404, { error: 'frame unavailable' })
        return
      }
      res.writeHead(200, {
        'content-type': 'image/webp',
        'cache-control': 'public, max-age=86400',
        'content-length': bytes.length,
      })
      res.end(bytes)
    },
  }
}

function mount(ctx, config = {}, eventCtx = ctx) {
  const logger = ctx.logger ?? console
  try {
    mountCompanion(ctx, config, eventCtx, logger)
  } catch (error) {
    // DSH treats a failing plugin activation as fatal for the whole boot
    // (dsh-app-boot rethrows init rejections). A host-side API change must
    // cost the pet its session, never the host its startup.
    logger.error?.(`dsh-dafeiyu failed to activate and stays disabled for this session: ${error instanceof Error ? error.message : String(error)}`)
  }
}

// The host's settings layer is authoritative while it works. The override
// store only fills in fields whose settings.update() write failed, so a
// native menu choice survives a Helper restart on hosts that cannot expose the
// bundle-patch entry (issue #95). A later host-side change clears that field's
// fallback again.
function createEffectiveSettings(host, overrides, logger) {
  const watchers = new Set()
  const current = () => overrides.apply(host.get())
  const announce = () => {
    const next = current()
    for (const callback of watchers) {
      try {
        callback(next)
      } catch (error) {
        logger.warn?.(`dsh-dafeiyu failed to deliver settings: ${error instanceof Error ? error.message : String(error)}`)
      }
    }
  }
  const offHost = host.watch?.(() => announce())
  return {
    namespace: host.namespace,
    describe: host.describe?.bind(host),
    get: current,
    watch(callback) {
      watchers.add(callback)
      return () => watchers.delete(callback)
    },
    ...(typeof host.update === 'function' ? {
      async update(patch) {
        await host.update(patch)
        overrides.clear(Object.keys(patch))
        announce()
      },
    } : {}),
    refresh: announce,
    dispose() {
      offHost?.()
      watchers.clear()
      host.dispose?.()
    },
  }
}

function mountCompanion(ctx, config = {}, eventCtx = ctx, logger) {
  const eventStream = createEventStream()
  const helperConfig = config.helper ?? {}
  // `helper.logFile: null` is the explicit test/custom-launch switch used by
  // HelperProcess; keep the settings diagnostics in the same file.
  const diagnosticsLog = createHelperLog(
    helperConfig.logFile === undefined ? defaultHelperLogPath() : helperConfig.logFile,
  )
  const hostSettings = createSettingsScope(ctx, Config, config, publicConfig)
  const overrides = createUserSettingsStore(defaultUserSettingsPath(), {
    warn(message) {
      diagnosticsLog.write('WARN', message)
      logger.warn?.(`dsh-dafeiyu ${message}`)
    },
  })
  const settings = createEffectiveSettings(hostSettings, overrides, logger)
  diagnosticsLog.write('INFO', `local fork build marker: version=${pkg.version} (${process.platform})`)
  let diagnosticsLogged = false

  let bridge
  let reducer
  let personaBridge
  let lastSessionActivity = 0
  let lastSessionId
  /** 桌面输入触发的待回显回复（sessionId + 时间戳）。 */
  let pendingChat
  let restartTimer
  const balance = createBalanceMonitor({
    query: createBalanceQuery(ctx),
    onChange(snapshot) {
      const message = createMessage(CompanionMessageKind.BALANCE, snapshot)
      if (bridge) bridge.send(message)
      else eventStream.broadcast(message)
    },
  })

  const stopRuntime = (reason = 'settings-change') => {
    personaBridge?.stop()
    personaBridge = undefined
    bridge?.stop(reason)
    bridge = undefined
    reducer = undefined
  }

  const restartRuntime = (next) => {
    stopRuntime('settings-change')
    startRuntime(next)
  }

  // `settings.describe()` lists the settings-page namespaces, not the
  // configEditor entries that `settings.update()` writes. Its absence of
  // "dsh-dafeiyu" is not evidence of a failed write (issue #95), so it is only
  // printed on an actual failure and labelled explicitly.
  const settingsPageNamespaceList = () => {
    try {
      return (hostSettings.describe?.() ?? []).map((row) => row.ns).join(',')
    } catch {
      return ''
    }
  }

  const helperEnvironment = (resolved) => ({
    ...helperConfig.env,
    DSH_DAFEIYU_SCALE: String(resolved.scale ?? defaults.scale),
    DSH_DAFEIYU_BUBBLE_SCALE: String(resolved.bubbleScale ?? defaults.bubbleScale),
    DSH_DAFEIYU_ACTIVITY_LEVEL: String(resolved.activityLevel ?? defaults.activityLevel),
    DSH_DAFEIYU_REDUCED_MOTION: resolved.reducedMotion === true ? '1' : '0',
    DSH_DAFEIYU_SOUND_ENABLED: resolved.soundEnabled !== false ? '1' : '0',
    DSH_DAFEIYU_SOUND_STATES: normalizeSoundStates(resolved.soundStates).join(','),
    DSH_DAFEIYU_BUBBLE_MODE: String(resolved.bubbleMode ?? defaults.bubbleMode),
    DSH_DAFEIYU_BUBBLE_STATES: (Array.isArray(resolved.bubbleStates) ? resolved.bubbleStates : defaults.bubbleStates).join(','),
    DSH_DAFEIYU_LOOK_THEME: String(resolved.lookTheme ?? defaults.lookTheme),
    DSH_DAFEIYU_LOOK_INTENSITY: String(resolved.lookIntensity ?? defaults.lookIntensity),
    DSH_DAFEIYU_WEBUI_URL: resolveClientTarget({ ...config, ...resolved }).url,
    DSH_DAFEIYU_OPEN_LABEL: resolveClientTarget({ ...config, ...resolved }).label,
  })

  const applyLiveSettings = (next) => {
    if (!bridge || !reducer) return
    // Keep the environment used by a later Helper spawn in sync with the live
    // config; otherwise a crashed Helper would restart with stale values until
    // the replayed CONFIG snapshot arrives.
    bridge.options.env = { ...bridge.options.env, ...helperEnvironment(next) }
    personaBridge?.updateConfig({
      enabled: next.personaEnabled !== false,
      idleMinutes: next.personaIdleMinutes ?? defaults.personaIdleMinutes,
    })
    for (const message of reducer.setIncludeSubagents(next.includeSubagents === true)) bridge.send(message)
    bridge.send(createMessage(CompanionMessageKind.CONFIG, {
      scale: next.scale ?? defaults.scale,
      bubbleScale: next.bubbleScale ?? defaults.bubbleScale,
      activityLevel: next.activityLevel ?? defaults.activityLevel,
      reducedMotion: next.reducedMotion === true,
      soundEnabled: next.soundEnabled !== false,
      soundStates: normalizeSoundStates(next.soundStates),
      bubbleMode: next.bubbleMode ?? defaults.bubbleMode,
      bubbleStates: Array.isArray(next.bubbleStates) ? next.bubbleStates : defaults.bubbleStates,
      lookTheme: next.lookTheme ?? defaults.lookTheme,
      lookIntensity: next.lookIntensity ?? defaults.lookIntensity,
      openUrl: resolveClientTarget({ ...config, ...next }).url,
      openLabel: resolveClientTarget({ ...config, ...next }).label,
    }))
  }

  const scheduleRestart = (next) => {
    if (restartTimer) clearTimeout(restartTimer)
    restartTimer = setTimeout(() => {
      restartTimer = undefined
      restartRuntime(next)
    }, 400)
    restartTimer.unref?.()
  }

  const sendBubble = (message, detail = '桌面对话') => {
    if (!bridge) return
    try {
      bridge.send(createMessage(CompanionMessageKind.TASK, { task: 'chat', message, detail }))
    } catch (error) {
      logger.warn?.(`dsh-dafeiyu chat bubble failed: ${error?.message ?? error}`)
    }
  }

  const handleDesktopChat = (payload) => {
    const message = buildFollowupMessage(payload?.text, payload?.mode)
    if (!message) return
    const agents = (() => {
      try {
        return ctx.get('agents')
      } catch {
        return undefined
      }
    })()
    const list = agents?.list?.() ?? []
    const target = list.find((agent) => agent.id === lastSessionId) ?? list[list.length - 1]
    if (!target?.followup) {
      sendBubble('没找到正在陪我干活的会话，先把 DSH 打开吧', '桌面对话')
      return
    }
    pendingChat = { sessionId: target.id, at: Date.now(), mode: payload.mode === 'task' ? 'task' : 'chat' }
    sendBubble(payload.mode === 'task' ? '收到任务，我先确认一下…' : '收到，我想想…', '桌面对话')
    try {
      Promise.resolve(target.followup(message)).catch((error) => {
        sendBubble(`没送出去：${error?.message ?? error}`, '桌面对话')
      })
    } catch (error) {
      sendBubble(`没送出去：${error?.message ?? error}`, '桌面对话')
    }
  }

  const startRuntime = (resolved) => {
    if (resolved.enabled === false) {
      logger.info?.('dsh-dafeiyu is disabled')
      return
    }
    bridge = new HelperProcess({
      ...helperConfig,
      env: helperEnvironment(resolved),
      onChat: (payload) => handleDesktopChat(payload),
      onSettingsChange: (report) => {
        if (typeof settings.update !== 'function') return
        const patch = {}
        if (Number.isFinite(report.scale)) patch.scale = Math.min(1.4, Math.max(0.55, report.scale))
        if (Number.isFinite(report.bubbleScale)) patch.bubbleScale = Math.min(1.2, Math.max(0.5, report.bubbleScale))
        if (typeof report.reducedMotion === 'boolean') patch.reducedMotion = report.reducedMotion
        if (Object.keys(patch).length === 0) return
        // Capture the host values before the write: the fallback only applies
        // while the host still holds the same baseline.
        const hostBefore = hostSettings.get()
        // Record before the write: DSH can resolve settings.update() without
        // the profile patch actually reaching disk. The store keeps the menu
        // value while the host holds either the old baseline or that value, and
        // a later host-side change (a third value) clears it.
        overrides.record(patch, hostBefore)
        void Promise.resolve(hostSettings.update(patch)).then(() => {
          diagnosticsLog.write('INFO', `persisted native menu settings: ${JSON.stringify(patch)}; fallback retained: ${JSON.stringify(overrides.snapshot())}`)
        }).catch((error) => {
          const detail = error instanceof Error ? error.message : String(error)
          diagnosticsLog.write(
            'ERROR',
            `settings.update failed for namespace "${hostSettings.namespace ?? 'dsh-dafeiyu'}": ${detail}; settings-page namespaces (describe, not write targets): ${settingsPageNamespaceList() || '(none)'}; kept native menu values: ${JSON.stringify(overrides.snapshot())}`,
          )
          logger.warn?.(`dsh-dafeiyu failed to persist helper settings: ${detail}`)
        }).finally(() => {
          // The Helper already applied the menu choice locally. Re-sending the
          // effective CONFIG keeps that choice in the replay snapshot if the
          // process restarts, and updates the environment for a later spawn.
          if (bridge) applyLiveSettings(settings.get())
        })
      },
    }, logger)
    // Mirror every companion message to in-page subscribers without changing
    // what the helper receives; the wrap is per-runtime and dies with it.
    const deliver = bridge.send.bind(bridge)
    bridge.send = (message) => {
      deliver(message)
      eventStream.broadcast(message)
    }
    reducer = new CompanionReducer({ includeSubagents: resolved.includeSubagents === true })
    // 人设桥：读 ~/.dsh/memory/persona.json，把成长/日记变成气泡。
    personaBridge = createPersonaBridge({
      dir: resolved.personaDir || undefined,
      send: (message) => {
        if (bridge) bridge.send(message)
      },
      isBusy: () => Date.now() - lastSessionActivity < 45_000,
      bubbleVisible: () => (settings.get().bubbleMode ?? defaults.bubbleMode) !== 'hidden',
      enabled: resolved.personaEnabled !== false,
      idleMinutes: resolved.personaIdleMinutes ?? defaults.personaIdleMinutes,
      logger,
    })
    personaBridge.start()
    if (!diagnosticsLogged) {
      diagnosticsLogged = true
      diagnosticsLog.write(
        'INFO',
        `settings persistence (activation): namespace="${hostSettings.namespace ?? 'dsh-dafeiyu'}"; update=${typeof hostSettings.update === 'function'}; native-menu fallback: ${JSON.stringify(overrides.snapshot())}`,
      )
    }
    bridge.start()
    bridge.send(createMessage(CompanionMessageKind.HELLO, {
      state: CompanionState.IDLE,
      host: 'deepseek-harness',
      pluginVersion: pkg.version,
      message: 'BigFish connected to DSH',
    }))
    bridge.send(createMessage(CompanionMessageKind.STATE, {
      state: CompanionState.IDLE,
      phase: 'plugin-start',
      stage: '等待任务',
      message: '我在这儿等新任务哦',
      detail: 'DSH · 等待下一次任务',
    }))
    if (balance.get().status !== 'disabled') bridge.send(createMessage(CompanionMessageKind.BALANCE, balance.get()))
    logger.info?.('dsh-dafeiyu companion bridge started')
  }

  startRuntime(settings.get())
  balance.configure(settings.get().enabled !== false && settings.get().balanceEnabled, settings.get().balanceSource)

  // The companion intentionally observes every DSH session. Loader entries may
  // live inside a scoped composition, so use the unscoped root bus and dispose
  // the registrations explicitly with this plugin's lifecycle.
  // Never let an exception from this optional companion escape into the shared
  // session bus: a throw here could stop every other subscriber from seeing
  // the event, which would look exactly like "installing the pet broke other
  // plugins".
  const offEvent = eventCtx.on('session/event', (session, event) => {
    lastSessionActivity = Date.now()
    lastSessionId = session?.id
    if (pendingChat && session?.id === pendingChat.sessionId && event?.type === 'assistant/message') {
      if (Date.now() - pendingChat.at < 10 * 60_000) {
        const text = bubblePreview(extractAssistantText(event))
        if (text) sendBubble(text, pendingChat.mode === 'task' ? '任务回复' : '桌面对话')
      }
      pendingChat = undefined
    }
    if (!bridge || !reducer) return
    try {
      for (const message of reducer.handle(session, event)) bridge.send(message)
    } catch (error) {
      logger.error?.('dsh-dafeiyu failed to handle session event', error)
    }
  }, { global: true })
  const offDisposed = eventCtx.on('session/disposed', (session) => {
    if (!bridge || !reducer) return
    try {
      for (const message of reducer.disposeSession(session)) bridge.send(message)
    } catch (error) {
      logger.error?.('dsh-dafeiyu failed to dispose session', error)
    }
  }, { global: true })

  const unwatch = settings.watch((next) => {
    // Disabling is the only path that tears the helper down.  Every other
    // setting is applied live through a CONFIG message, so sliders never
    // restart the pet.  Starting a previously-disabled runtime is debounced
    // to avoid spawning repeatedly while settings settle.
    try {
      balance.configure(next.enabled !== false && next.balanceEnabled, next.balanceSource)
      if (next.enabled === false) {
        if (restartTimer) {
          clearTimeout(restartTimer)
          restartTimer = undefined
        }
        stopRuntime('settings-change')
        return
      }
      if (!bridge) {
        scheduleRestart(next)
        return
      }
      if (restartTimer) {
        clearTimeout(restartTimer)
        restartTimer = undefined
      }
      applyLiveSettings(next)
    } catch (error) {
      // This callback runs inside the host's settings dispatch; a throw here
      // would take the host's settings service down with the pet.
      logger.error?.(`dsh-dafeiyu failed to apply settings: ${error instanceof Error ? error.message : String(error)}`)
    }
  })
  // A credential or account change invalidates the old display immediately.
  const refreshBalance = () => {
    const next = settings.get()
    balance.configure(next.enabled !== false && next.balanceEnabled, next.balanceSource, true)
  }
  const offCredential = eventCtx.on('credentials/reference-updated', refreshBalance, { global: true })
  const offAccount = eventCtx.on('deepseek-account/signed-out', refreshBalance, { global: true })
  const offAccountCredential = eventCtx.on('credentials/record-updated', refreshBalance, { global: true })
  const offProvider = eventCtx.on('settings/document-updated', (ns) => {
    if (['llm-deepseek', 'llm-deepseek-api-key', balanceProviderNamespace(ctx)].includes(ns)) refreshBalance()
  }, { global: true })
  if (typeof ctx.inject === 'function') {
    ctx.inject(['webServer'], (httpCtx) => {
      httpCtx.effect(
        () => httpCtx.webServer.register({ kind: 'exact', path: CONFIG_ENDPOINT, handler: createConfigHandler(settings) }),
        'dsh-dafeiyu: local settings endpoint',
      )
      httpCtx.effect(
        () => httpCtx.webServer.register({ kind: 'exact', path: EVENTS_ENDPOINT, handler: createEventsHandler(eventStream) }),
        'dsh-dafeiyu: local event stream',
      )
      httpCtx.effect(
        () => httpCtx.webServer.register({ kind: 'exact', path: BALANCE_ENDPOINT, handler: createBalanceHandler(balance) }),
        'dsh-dafeiyu: local balance endpoint',
      )
      const assetRoutes = createAssetRoutes()
      if (assetRoutes) {
        httpCtx.effect(
          () => httpCtx.webServer.register({ kind: 'exact', path: MANIFEST_ENDPOINT, handler: assetRoutes.manifestHandler }),
          'dsh-dafeiyu: local manifest endpoint',
        )
        httpCtx.effect(
          () => httpCtx.webServer.register({ kind: 'exact', path: FRAME_ENDPOINT, handler: assetRoutes.frameHandler }),
          'dsh-dafeiyu: local frame endpoint',
        )
      }
    })
  }
  ctx.effect(() => () => {
    if (restartTimer) clearTimeout(restartTimer)
    restartTimer = undefined
    offEvent?.()
    offDisposed?.()
    offCredential?.()
    offAccount?.()
    offAccountCredential?.()
    offProvider?.()
    unwatch()
    settings.dispose?.()
    balance.stop()
    stopRuntime('dsh-host-stop')
  })
}

export function apply(ctx, config = {}) {
  // Settings is already a declared dependency. Keep observers on this fiber
  // so Loader's fiber-scoped volatile updates reach them.
  mount(ctx, config)
}

export {
  CompanionMessageKind,
  CompanionReducer,
  CompanionState,
  HelperProcess,
}
